#!/bin/sh
java -cp lib/fitnesse.jar fitnesse.FitNesse -e 0 -o -p 8080 $1 $2 $3 $4 $5



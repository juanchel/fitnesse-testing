Python FixtureGallery Examples
===============================================================================

:Author:   Jens Engel
:License:  GNU GPL
:Requires: Python >= 2.4
:Requires: PyFIT  >= 0.8A2 (already provided here)

This directory contains all resources to run the FixtureGallery examples
with Python.

Files:

  * fit.zip: PyFIT 0.8A2: FIT, FitLibrary and FitDecorator as ZIP package.
    NOTE: Slightly adapted and bundled together.

  * info.fitnesse.fixturegallery.zip: Source code to FixtureGallery examples.

  * FitServer.py: PyFIT script to start Python FitServer, used by Fitnesse.
    NOTE: Adapted to load FIT library from ZIP file.


Copyright Remarks
-------------------------------------------------------------------------------

  * PyFIT (Python port of FIT and FitLibrary): Copyright by John Roth
  * FitDecorator (Python port): Copyright by Jens Engel

#!/usr/bin/env python
# PYTHON-SCRIPT: FitServer.py as part of PyFIT distribution.
# DESCRIPTION: Starts Python FitServer to run FIT tests with FitNesse.

# == SPECIAL PART: Add ZIP package of FIT framework (and FitLibrary).
import os.path
import sys

HERE = os.path.dirname(__file__)
FIT_PACKAGE = os.path.join(HERE, "fit.zip")
if os.path.exists(FIT_PACKAGE):
    sys.path.insert(0, FIT_PACKAGE)

# -- ORIGINAL-PART: Below this line -------------------------------------------
#! python ???
# FitServer stub
# copyright 2005 John H. Roth Jr
# released under the GNU General Public License, version 2.0 or higher

# ALREADY: import sys
from fitnesse.FitServerImplementation import FitServer

if __name__ == "__main__":
    obj = FitServer()
    result = obj.run(sys.argv)
    sys.exit(result)

#!/usr/bin/env python
# PYTHON-SCRIPT: TestRunner.py as part of PyFIT distribution.
# DESCRIPTION: Batch-driven execution of Fitnesse tests.
# == SPECIAL PART: Add ZIP package of FIT framework (and FitLibrary).
import os.path
import sys

HERE = os.path.dirname(__file__)
FIT_PACKAGE = os.path.join(HERE, "fit.zip")
if os.path.exists(FIT_PACKAGE):
    sys.path.insert(0, FIT_PACKAGE)

# -- ORIGINAL-PART: Below this line -------------------------------------------
#! python
# TestRunner stub
# copyright 2005 John H. Roth Jr
# released under the GNU General Public License, version 2.0 or higher

import sys
from fitnesse.FitServerImplementation import TestRunner

if __name__ == "__main__":
    obj = TestRunner()
    result = obj.run(sys.argv)
    sys.exit(result)
